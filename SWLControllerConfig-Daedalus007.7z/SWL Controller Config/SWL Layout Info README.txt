Layout created by JcDenton2k @ GitHub,
I am known as Daedalus007 in-game on Secret World Legends (SWL).
Feel free to send me in-game mail if this layout helped you out!

All files in this archive are released under the following Creative Commons license:
https://creativecommons.org/licenses/by-nc-sa/4.0/legalcode



Info on files included and what they do:

SWL Layout Info.txt
--This file that you are reading right now!

hotkeys.xml
--Easy way to change hotkeys without having to do so manually
--Place in the following folder:  %localappdata%\Funcom\SWL\Prefs

swl-layout.png
--Visual indication of the Hotkey Layout for those who don't want to use my hotkeys.xml file

SWL.gamecontroller.amgp
--Profile for the AntiMicro Program
--Download AntiMicro from GitHub: https://github.com/AntiMicro/antimicro/releases

